from setuptools import setup

setup(
    name="paqueteCLientes",
    version="1.0",
    description="paquete con uso de POO, instaciar objetos de la clase Cliente",
    author="Miller Ladino",
    author_email="millerladino@gmail.com",
    url="https://github.com/millertsu1",
    packages=["clients","clients.add_clients"]
)